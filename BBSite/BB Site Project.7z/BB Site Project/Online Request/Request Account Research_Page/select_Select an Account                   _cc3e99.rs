<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>select_Select an Account                   _cc3e99</name>
   <tag></tag>
   <elementGuidId>851c13b8-1a33-442d-b954-1a1fa48a1bba</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>select[name=&quot;Chosen_Account&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>//*[@name = 'Chosen_Account' and (text() = '
                                      Select an Account
                                01110000 - HECHT_SAVINGS 011100000001110001 - CUENTAS LOUIS LOANS 10000111100001110100 - SAVINGS 0111012901110101 - Checking 0111010101110200 - SAVINGS 0111020101110201 - Checking 01110201' or . = '
                                      Select an Account
                                01110000 - HECHT_SAVINGS 011100000001110001 - CUENTAS LOUIS LOANS 10000111100001110100 - SAVINGS 0111012901110101 - Checking 0111010101110200 - SAVINGS 0111020101110201 - Checking 01110201')]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//select[@name='Chosen_Account']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>select</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>name</name>
      <type>Main</type>
      <value>Chosen_Account</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                                      Select an Account
                                01110000 - HECHT_SAVINGS 011100000001110001 - CUENTAS LOUIS LOANS 10000111100001110100 - SAVINGS 0111012901110101 - Checking 0111010101110200 - SAVINGS 0111020101110201 - Checking 01110201</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;ccForm&quot;)/div[@class=&quot;dataTable&quot;]/table[@class=&quot;chart noBorder&quot;]/tbody[1]/tr[1]/td[@class=&quot;datacol&quot;]/select[1]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//select[@name='Chosen_Account']</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//form[@id='ccForm']/div[2]/table/tbody/tr/td[2]/select</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='*'])[4]/following::select[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Bills'])[1]/preceding::select[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Hundreds (Straps of 10,000.00)'])[1]/preceding::select[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//select</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//select[@name = 'Chosen_Account' and (text() = '
                                      Select an Account
                                01110000 - HECHT_SAVINGS 011100000001110001 - CUENTAS LOUIS LOANS 10000111100001110100 - SAVINGS 0111012901110101 - Checking 0111010101110200 - SAVINGS 0111020101110201 - Checking 01110201' or . = '
                                      Select an Account
                                01110000 - HECHT_SAVINGS 011100000001110001 - CUENTAS LOUIS LOANS 10000111100001110100 - SAVINGS 0111012901110101 - Checking 0111010101110200 - SAVINGS 0111020101110201 - Checking 01110201')]</value>
   </webElementXpaths>
</WebElementEntity>
